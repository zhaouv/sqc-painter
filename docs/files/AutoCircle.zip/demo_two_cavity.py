# -*- coding: utf-8 -*-

#初始化
import sys
import os
#
sys.path.append(os.path.dirname(__file__))

import json
import pya
import paintlib
from imp import reload
reload(paintlib)
layout,top = paintlib.IO.Start("guinew")#在当前的图上继续画,如果没有就创建一个新的
layout.dbu = 0.001#设置单位长度为1nm
paintlib.IO.pointdistance=2000#设置腔的精度,转弯处相邻两点的距离
TBD=paintlib.TBD.init(8729813)

with open('args/now.json',encoding='utf-8') as fid:
    args=json.load(fid)




#参数



#创建cell和layer的结构

layerTr=layout.layer(10, 10)

cellTr=layout.create_cell("cellTr")
top.insert(pya.CellInstArray(cellTr.cell_index(),pya.Trans()))

layerC=layout.layer(10, 1)

cellC=layout.create_cell("cellC")
top.insert(pya.CellInstArray(cellC.cell_index(),pya.Trans()))


#画传输线

brush1=paintlib.CavityBrush(pointc=pya.DPoint(0,0),angle=0,widout=20000,widin=10000,bgn_ext=0)

painter1=paintlib.CavityPainter(brush1,end_ext=0)
painter1.Electrode(reverse=True)
painter1.Run('s 1500000 r 500000,180 s 1500000')
painter1.Electrode()
painter1.Draw(cellTr,layerTr)

#画腔1
painter_=paintlib.CavityPainter(brush1)
painter_.Run('s 500000')
painter_.Run('s 10000 l 13000,180 s 10000')
brush2=painter_.brush.reversed()

lengthOfC1=args['lc1']

painter2=paintlib.CavityPainter(pointc=pya.DPoint(brush2.centerx,brush2.centery),angle=brush2.angle,widout=24000,widin=8000,bgn_ext=8000,end_ext=8000)
dl=TBD.get()
l1=painter2.Run('s 300000 l 50000 s 200000 n7[l 50000 s{l} r 50000,180 s{l} l 50000] l 50000 s 100000'.format(l=dl/14))
TBD.set(lengthOfC1-l1)
painter2.Draw(cellC,layerC)

#画腔2
painter_=paintlib.CavityPainter(brush1)
painter_.Run('s 1500000 r 500000,180 s{}'.format(1500000-500000-300000-74000))
painter_.Run('s 10000 l 13000,180 s 10000')
brush3=painter_.brush.reversed()

lengthOfC2=args['lc2']

painter3=paintlib.CavityPainter(pointc=pya.DPoint(brush3.centerx,brush3.centery),angle=brush3.angle,widout=24000,widin=8000,bgn_ext=8000,end_ext=8000)
dl=TBD.get()
l2=painter3.Run('s 300000 l 50000 s 200000 s 1400000 l 50000 s{l1} l 50000 n4[l 50000 s{l} r 50000,180 s{l} l 50000] '.format(l=dl/8,l1=300000-62000))
TBD.set(lengthOfC2-l2)
painter3.Draw(cellC,layerC)



TBDFinish=TBD.isFinish()
print(TBDFinish)

if TBDFinish:
    #
    import simulation
    reload(simulation)
    Simulation=simulation.Simulation

    painter_=painter2
    painter_tl=painter1
    name_='cavity1'

    Simulation.create(
        name=name_,startfrequency=args['startfrequency'],endfrequency=args['endfrequency'],freqnum=args['freqnum'],
        layerlist=[(10,1),(10,10)],boxx=850000,boxy=2200000,
        region=painter_.region,brush=None,transmissionlines=[painter_tl.Getcenterlineinfo()],portbrushs=None,porttype=[0,0],parametertype='S',speed=args['speed'],
        offsetx=0,offsety=0,deltaangle=0,absx=None,absy=None,
        crossoverLayerList=None,extra={"postfix":args['postfix'],"type":2}
        )
    
    painter_=painter3
    painter_tl=painter1
    name_='cavity2'

    Simulation.create(
        name=name_,startfrequency=args['startfrequency'],endfrequency=args['endfrequency'],freqnum=args['freqnum'],
        layerlist=[(10,1),(10,10)],boxx=850000,boxy=2200000,
        region=painter_.region,brush=None,transmissionlines=[painter_tl.Getcenterlineinfo()],portbrushs=None,porttype=[0,0],parametertype='S',speed=args['speed'],
        offsetx=0,offsety=0,deltaangle=0,absx=None,absy=None,
        crossoverLayerList=None,extra={"postfix":args['postfix'],"type":2}
        )

    if args['outputgds']:
        paintlib.IO.Write(args['outputgds'])#输出到文件中


paintlib.IO.Show()#输出到屏幕上
#