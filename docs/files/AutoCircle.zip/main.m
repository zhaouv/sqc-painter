% json=struct('loads',@(str)subsref(loadjson(['["",' str ']']),struct('type','{}','subs',{{2}})),'dumps',@(obj)savejson('',obj));
json=struct('loads',@(str)jsondecode(str),'dumps',@(obj)jsonencode(obj));

%%


tic;
maintype=2;
%%
for ii = 3900000:10000:4000000
    maininput=ii;
    disp(maininput);
    %%
    fid=fopen('args/now.json','r');
    text=fread(fid);
    fclose(fid);
    text=char(text');
    args=json.loads(text);
    args.maintype=maintype;
    %%
    if maintype==1
        args.lc1=maininput;
        args.speed=2;
        args.startfrequency=6;
        args.endfrequency=8;
        args.freqnum=500;
    end
    if maintype==2
        args.lc2=maininput;
        args.speed=0;
        args.startfrequency=6;
        args.endfrequency=8;
        args.freqnum=2000;
    end
    %%
    fid=fopen('args/now.json','w');
    fprintf(fid,json.dumps(args));
    fclose(fid);
    maincontrol;
    toc;
end