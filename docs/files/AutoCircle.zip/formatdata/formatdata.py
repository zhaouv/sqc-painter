# -*- coding: utf-8 -*-

import os
import json
path='../result/'
typestr='sonnet_2_'
result=[]
for i in os.listdir(path):
    if i[-5:]!='.json':continue
    if i[:len(typestr)]!=typestr:continue
    tempname=path+'/'+i
    with open(tempname) as fid:
        obj=json.load(fid)
    if obj['speed']==2:continue
    result.append([obj['input'],obj['output']])
result.sort(key=lambda x:x[0])
r={'x':[a[0] for a in result],'y':[a[1] for a in result],'xy':result}
print(r)
with open(typestr[:-1]+'.json','w') as fid:
    #print(result,file=fid)
    json.dump(r,fid)