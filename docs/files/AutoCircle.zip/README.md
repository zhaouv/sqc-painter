## 关于实例的说明

实例的python脚本画了两种腔, 并设置不同的参数仿真

程序的逻辑是matlab脚本做为主控程序

跑循环来通过json设置设计参数, 通过命令行来执行klayout画图, 再调sonnetLab仿真

## 使用

使用时将库复制到此目录

设置gener.cmd中的脚本名以及klayout可执行程序的路径

simulation-matlab/目录下的 addPortCocalibrateAtLocation.m 和 fixFormat.py 复制出来

将matlab模板文件中的数据处理部分删除, 

入口文件是**main.m**或**findroot.m**, 分别用于扫描参数得到值和求目标值对应的参数

**formardata/**目录用来处理数据

**findroot.m**使用弦截法求值, 需要初始情况有两个符号相反的点已知

提供了**next_input.json**在弦截法中可以先扫描完其中的数之后再进行正常求根, 将`on`设为1, `input`内填要先扫描的数组即可在弦截法中使用

两点关于代码风格的说明
+ 刻意写成脚本而没有使用函数, 是为了方便随时打断和继续
+ **maincontrol.m**中大量的move操作, 是为了能够容易的区分正在进行的放弃的sonnet项目

