% json=struct('loads',@(str)subsref(loadjson(['["",' str ']']),struct('type','{}','subs',{{2}})),'dumps',@(obj)savejson('',obj));
json=struct('loads',@(str)jsondecode(str),'dumps',@(obj)jsonencode(obj));
%%
maintype=2;
%%
targety=7.1;
x0=[ 4086278,4129272];
y0=[ 7.1505, 7.0785]-targety;
maxtime=12;
yeps=0.001001;
xeps=100;
%%
[~,sorti]=sort(x0);
x0s=x0(sorti);
y0s=y0(sorti);
tracexy=struct('x',x0s,'y',y0s);
figure(1054);plot(tracexy.x,tracexy.y,tracexy.x,tracexy.y,'o')
rx=x0s(1);
ry=y0s(1);
tic;
for tt = 1:maxtime
    disp('time')
    disp(tt)
    fid=fopen('args/next_input.json','r');
    text=fread(fid);
    fclose(fid);
    text=char(text');
    next_input=json.loads(text);
    if next_input.on
        rx=next_input.input(1);
        next_input.used(end+1)=rx;
        next_input.input=next_input.input(2:end);
        if size(next_input.input,1)+size(next_input.input,2)==1
            next_input.on=false;
            next_input.input=[0,0];
        end
        fid=fopen('args/next_input.json','w');
        fprintf(fid,json.dumps(next_input));
        fclose(fid);
    else
        [~,sorti]=sort(tracexy.x);
        g=@(t)interp1(tracexy.x(sorti),tracexy.y(sorti),t);
        rx = fzero(g,[x0s(1),x0s(end)]);
        rx=floor(rx);
    end
    maininput=rx;
    disp('input')
    disp(maininput);
    %%
    % ------ % ry = f(rx);
    fid=fopen('args/now.json','r');
    text=fread(fid);
    fclose(fid);
    text=char(text');
    args=json.loads(text);
    args.maintype=maintype;
    %%
    if maintype==1
        args.lc1=maininput;
        args.speed=2;
        args.startfrequency=6;
        args.endfrequency=8;
        args.freqnum=500;
    end
    if maintype==2
        args.lc2=maininput;
        args.speed=0;
        args.startfrequency=6;
        args.endfrequency=8;
        args.freqnum=2000;
    end
    %%
    fid=fopen('args/now.json','w');
    fprintf(fid,json.dumps(args));
    fclose(fid);
    maincontrol;
    toc;
    ry=output-targety;
    %%
    tracexy.x(end+1)=rx;
    tracexy.y(end+1)=ry;
    figure(1054);plot(tracexy.x,tracexy.y,tracexy.x,tracexy.y,'o')
    if abs(ry) <= yeps
        break;
    end
    if abs(rx-tracexy.x(end-1)) <= xeps
        break;
    end
end

% output is rx~ry

% figure(1054);plot(tracexy.x,tracexy.y,tracexy.x,tracexy.y,'o')

% 1;figure;ezplot(g,[x0(1),x0(2)]);hold on;ezplot(f,[x0(1),x0(2)])