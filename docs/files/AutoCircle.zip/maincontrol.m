
dt = datestr(now,'yyyymmdd_HHMMSS');
%%
fid=fopen('args/now.json','r');
text=fread(fid);
fclose(fid);
text=char(text');
args=json.loads(text);
%%
args.postfix=['sonnet_',num2str(maintype),'_',dt];
args.maintype=maintype;
if maintype==1
end
if maintype==2
end
%%
fid=fopen('args/now.json','w');
fprintf(fid,json.dumps(args));
fclose(fid);
%%
command='gener.cmd';
[status,cmdout] = system(command);
disp(status);
disp(cmdout);
if status~=0
    error('build gds error');
end
%%
newname=['sonnet_',num2str(maintype),'_',dt];
if maintype==1
    command=['move ','sonnet_cavity1.m ',newname,'.m'];
    args.input=args.cargs{2}.clength;
end
if maintype==2
    command=['move ','sonnet_cavity2.m ',newname,'.m'];
    args.input=args.cargs{4}.clength;
end
[status,cmdout] = system(command);
if status~=0
    error('rename .m file error');
end
run([newname,'.m']);
% Read Touchstone Output File for S11 and S21
snpfilename_=[project_name_,'.s',num2str(portnum_),'p'];
S21 = TouchstoneParser(snpfilename_,2,1);
ex=TBD_projectname_extra;
if ex.type == 1
Cc=10^7/(2*pi*imag(1/S21(1,2)));
output=Cc;
end
if ex.type==2
[S21min,nmin]=min(abs(S21(:,2)));
f0readcav=S21(nmin,1);
output=f0readcav;
end
if ex.type==3
[S21max,nmax]=max(abs(S21(:,2)));
f0coupcav=S21(nmax,1);
output=f0coupcav;
end
%%
args.output=output;
fid=fopen(['result/',newname,'.json'],'w');
fprintf(fid,json.dumps(args));
fclose(fid);
[status,cmdout] = system(['move ',newname,'.m result/',newname,'.m']);
if status~=0
    error('move .m file error');
end
[status,cmdout] = system(['move ',newname,'.son result/',newname,'.son']);
if status~=0
    error('move .son file error');
end
[status,cmdout] = system(['move ',newname,'.s2p result/',newname,'.s2p']);
if status~=0
    error('move .s2p file error');
end
[status,cmdout] = system(['move sondata/',newname,' result/sondata/',newname]);
if status~=0
    error('move sondata.folder file error');
end